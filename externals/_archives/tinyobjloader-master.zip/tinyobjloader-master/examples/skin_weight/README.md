This example printf skin weight of vertex(`vw`). TinyObjLoader extension.

## Run example

```
$ ./skin_weight ../../models/skin-weight.obj
```
