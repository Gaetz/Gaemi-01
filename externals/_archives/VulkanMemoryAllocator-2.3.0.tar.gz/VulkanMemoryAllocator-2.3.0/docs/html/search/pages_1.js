var searchData=
[
  ['choosing_20memory_20type_444',['Choosing memory type',['../choosing_memory_type.html',1,'']]],
  ['configuration_445',['Configuration',['../configuration.html',1,'']]],
  ['custom_20memory_20pools_446',['Custom memory pools',['../custom_memory_pools.html',1,'']]]
];
