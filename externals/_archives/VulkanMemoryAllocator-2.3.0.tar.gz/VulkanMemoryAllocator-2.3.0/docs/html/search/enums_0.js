var searchData=
[
  ['vmaallocationcreateflagbits_392',['VmaAllocationCreateFlagBits',['../vk__mem__alloc_8h.html#ad9889c10c798b040d59c92f257cae597',1,'vk_mem_alloc.h']]],
  ['vmaallocatorcreateflagbits_393',['VmaAllocatorCreateFlagBits',['../vk__mem__alloc_8h.html#a4f87c9100d154a65a4ad495f7763cf7c',1,'vk_mem_alloc.h']]],
  ['vmadefragmentationflagbits_394',['VmaDefragmentationFlagBits',['../vk__mem__alloc_8h.html#a6552a65b71d16f378c6994b3ceaef50c',1,'vk_mem_alloc.h']]],
  ['vmamemoryusage_395',['VmaMemoryUsage',['../vk__mem__alloc_8h.html#aa5846affa1e9da3800e3e78fae2305cc',1,'vk_mem_alloc.h']]],
  ['vmapoolcreateflagbits_396',['VmaPoolCreateFlagBits',['../vk__mem__alloc_8h.html#a9a7c45f9c863695d98c83fa5ac940fe7',1,'vk_mem_alloc.h']]],
  ['vmarecordflagbits_397',['VmaRecordFlagBits',['../vk__mem__alloc_8h.html#a4dd2c44642312a147a4e93373a6e64d2',1,'vk_mem_alloc.h']]]
];
