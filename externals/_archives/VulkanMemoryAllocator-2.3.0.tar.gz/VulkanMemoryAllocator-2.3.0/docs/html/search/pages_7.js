var searchData=
[
  ['record_20and_20replay_454',['Record and replay',['../record_and_replay.html',1,'']]],
  ['recommended_20usage_20patterns_455',['Recommended usage patterns',['../usage_patterns.html',1,'']]]
];
