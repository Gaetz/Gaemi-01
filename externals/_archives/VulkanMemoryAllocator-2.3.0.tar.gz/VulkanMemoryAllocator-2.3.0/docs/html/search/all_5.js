var searchData=
[
  ['general_20considerations_25',['General considerations',['../general_considerations.html',1,'']]]
];
