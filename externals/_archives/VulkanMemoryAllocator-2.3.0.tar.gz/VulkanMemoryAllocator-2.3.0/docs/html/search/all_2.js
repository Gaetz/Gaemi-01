var searchData=
[
  ['choosing_20memory_20type_13',['Choosing memory type',['../choosing_memory_type.html',1,'']]],
  ['commandbuffer_14',['commandBuffer',['../struct_vma_defragmentation_info2.html#a7f71f39590c5316771493d2333f9c1bd',1,'VmaDefragmentationInfo2']]],
  ['configuration_15',['Configuration',['../configuration.html',1,'']]],
  ['custom_20memory_20pools_16',['Custom memory pools',['../custom_memory_pools.html',1,'']]]
];
