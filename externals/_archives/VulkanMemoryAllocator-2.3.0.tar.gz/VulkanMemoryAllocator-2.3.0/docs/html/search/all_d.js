var searchData=
[
  ['record_20and_20replay_64',['Record and replay',['../record_and_replay.html',1,'']]],
  ['requiredflags_65',['requiredFlags',['../struct_vma_allocation_create_info.html#a9166390303ff42d783305bc31c2b6b90',1,'VmaAllocationCreateInfo']]],
  ['recommended_20usage_20patterns_66',['Recommended usage patterns',['../usage_patterns.html',1,'']]]
];
